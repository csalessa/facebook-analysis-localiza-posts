# Localiza Facebook Posts Analysis

The main goal of this project
is to measure the engagement in facebook posts
regarding #localiza.

Setting up environment:

[ TODO :)]

Future work:
* filter file by date
* Get data directly from facebook
* Get distric list and group places to see relevance as a travel term
